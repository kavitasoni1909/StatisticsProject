package com.ec.lab;

import javax.naming.InitialContext;
import javax.naming.NamingException;

public class EJBClient {
	public static void main(String[] args) throws NamingException {

		MyStatsSingletonRemote singleton = (MyStatsSingletonRemote) InitialContext
				.doLookup("stats-ejb/StatsEJBSingleton!com.ec.lab.MyStatsSingletonRemote");
		for (int i = 1; i <= 10; i++) {
			singleton.addData(i);
		}
		singleton.saveModel();

		StatsEJBStatelessRemote stateless = (StatsEJBStatelessRemote) InitialContext
				.doLookup("stats-ejb/StatsEJBStateless!com.ec.lab.StatsEJBStatelessRemote");
		System.out.println("Count : " + stateless.getCount());
		System.out.println("Mean : " + stateless.getMean());

		StatsEJBStatefulRemote stateful = (StatsEJBStatefulRemote) InitialContext
				.doLookup("stats-ejb/StatsEJBStateful!com.ec.lab.StatsEJBStatefulRemote");
		for (int i = 11; i <= 100; i++) {
			stateful.insertData(i);
		}
		stateful.createModel();
		System.out.println(stateful.getStats());

		System.out.println("RMI done!");
	}
}
