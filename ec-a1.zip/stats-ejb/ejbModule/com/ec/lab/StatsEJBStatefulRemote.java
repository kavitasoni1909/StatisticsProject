package com.ec.lab;

import javax.ejb.Remote;

@Remote
public interface StatsEJBStatefulRemote {
	public void insertData(double data); // to the StatsEJBSingleton object.
	public void createModel() ; // save the stats summary model StatsEJBSingleton. 
	public String getStats(); // get the stats summary string by the StatsEJBStateless object.
}
