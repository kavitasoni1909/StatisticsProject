package com.ec.lab;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import org.jboss.logging.Logger;

/**
 * Session Bean implementation class SBStateless
 */
@Stateless
@LocalBean
public class StatsEJBStateless implements StatsEJBStatelessRemote, StatsEJBStatelessLocal {
	private static final Logger LOGGER = Logger.getLogger(StatsEJBStateless.class);

	@EJB
	private MyStatsSingletonLocal sbsgt;

	/**
	 * Default constructor.
	 */
	public StatsEJBStateless() {
	}

	@Override
	public int getCount() {
		StatsSummary summary = loadModel();
		return summary.getCount();
	}

	@Override
	public double getMin() {
		StatsSummary summary = loadModel();
		return summary.getMin();
	}

	@Override
	public double getMax() {
		StatsSummary summary = loadModel();
		return summary.getMax();
	}

	@Override
	public double getMean() {
		StatsSummary summary = loadModel();
		return summary.getMean();
	}

	@Override
	public double getSTD() {
		StatsSummary summary = loadModel();
		return summary.getStd();
	}

	@Override
	public String toString() {
		StatsSummary summary = loadModel();
		return summary.toString();
	}
	
	public StatsSummary loadModel() {
		StatsSummary summary = new StatsSummary();
		try {
			FileInputStream f = new FileInputStream("C:\\EC\\workspace\\model\\stats.bin");
			ObjectInputStream o = new ObjectInputStream(f);

			// Write objects to file
			summary = (StatsSummary) o.readObject();
			o.close();
			f.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return summary;
	}
}
