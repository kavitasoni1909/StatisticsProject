package com.ec.lab;

import java.io.Serializable;

public class StatsSummary implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6130944735715280946L;
	private double min, max;
	private int count;
	private double mean;
	private double std;

	StatsSummary(int count, double min, double max, double mean, double std) {
		this.count = count;
		this.min = min;
		this.max = max;
		this.mean = mean;
		this.std = std;
	}

	public StatsSummary() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Count:" + count + "\nMin: " + min + "\nMax: " + max + "\nMean: " + mean + "\nSTD: " + std;
	}

	public double getMin() {
		return min;
	}

	public double getMax() {
		return max;
	}

	public int getCount() {
		return count;
	}

	public double getMean() {
		return mean;
	}

	public double getStd() {
		return std;
	}
}
