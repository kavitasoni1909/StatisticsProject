package com.ec.lab;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;

import javax.ejb.LocalBean;
import javax.ejb.Singleton;

/**
 * Session Bean implementation class SBSingleton
 */
@Singleton
@LocalBean
public class StatsEJBSingleton implements MyStatsSingletonRemote, MyStatsSingletonLocal {
	private ArrayList<Double> list = new ArrayList();
	private double min, max;
	private int count;
	private double mean;
	private double std;

	/**
	 * Default constructor.
	 */
	public StatsEJBSingleton() {
	}

	@Override
	public void addData(double data) {
		list.add(data);
	}

	@Override
	public int getCount() {
		return list.size();
	}

	@Override
	public void stats() {
		count = getCount();
		min = getMin();
		max = getMax();
		mean = getMean();
		std = getSTD();
	}

	@Override
	public void saveModel() {
		stats();
		StatsSummary summary = new StatsSummary(count, min, max, mean, std);
		
		try {
			FileOutputStream f = new FileOutputStream("C:\\EC\\workspace\\model\\stats.bin");
			ObjectOutputStream o = new ObjectOutputStream(f);

			// Write objects to file
			o.writeObject(summary);
			o.close();
			f.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public double getMin() {
		return Collections.min(list);
	}

	public double getMax() {
		return Collections.max(list);
	}

	public double getMean() {
		double sum = 0;
		for (double i : list) {
			sum += i;
		}
		return sum / list.size();
	}

	public double getSTD() {
		double standardDeviation = 0.0;

		for (double i : list) {
			standardDeviation += Math.pow(i - mean, 2);
		}
		return Math.sqrt(standardDeviation / count);
	}
}
