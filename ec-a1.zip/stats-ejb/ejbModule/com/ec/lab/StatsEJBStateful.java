package com.ec.lab;

import javax.ejb.EJB;
import javax.ejb.Stateful;

/**
 * Session Bean implementation class SBStateful
 */
@Stateful
public class StatsEJBStateful implements StatsEJBStatefulRemote, StatsEJBStatefulLocal {

	@EJB
    private StatsEJBSingleton singleton;
	private StatsEJBStateless stateless;
	
    public StatsEJBStateful() {
    }

	@Override
	public void insertData(double data) {
		singleton.addData(data);
	}

	@Override
	public void createModel() {
		singleton.saveModel();
	}

	@Override
	public String getStats() {
		return stateless.toString();
	}

    

}
