package com.ec.lab;

import javax.ejb.Local;

@Local
public interface MyStatsSingletonLocal {

	public void addData(double data); // adding a data element

	public int getCount(); // returning the number of elements

	public void stats(); // computing the descriptive statistics

	public void saveModel(); // saving the serializable object 
}
