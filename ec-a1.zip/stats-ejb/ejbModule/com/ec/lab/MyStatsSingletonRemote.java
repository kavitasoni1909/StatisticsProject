package com.ec.lab;

import javax.ejb.Remote;

@Remote
public interface MyStatsSingletonRemote {
	public void addData(double data); // adding a data element

	public int getCount(); // returning the number of elements

	public void stats(); // computing the descriptive statistics

	public void saveModel(); // saving the serializable object

}
