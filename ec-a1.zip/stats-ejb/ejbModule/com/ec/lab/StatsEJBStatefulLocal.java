package com.ec.lab;

import javax.ejb.Local;

@Local
public interface StatsEJBStatefulLocal {
	public void insertData(double data); // to the StatsEJBSingleton object.

	public void createModel(); // save the stats summary model StatsEJBSingleton.

	public String getStats(); // get the stats summary string by the StatsEJBStateless object.
}
