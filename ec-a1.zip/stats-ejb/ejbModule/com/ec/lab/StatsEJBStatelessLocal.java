package com.ec.lab;

import javax.ejb.Local;

@Local
public interface StatsEJBStatelessLocal {
	public int getCount(); // returning the data count

	public double getMin(); // getting the minimum element

	public double getMax(); // getting maximum element

	public double getMean(); // getting the mean

	public double getSTD(); // getting the standard deviation

	public String toString(); // returning a String of the simple stats summary
}
