package com.ec.lab;

import java.util.ArrayList;
import java.util.Collections;

public class Statistics implements StatisticsI {
	
	private ArrayList<Double> list = new ArrayList();
	private double min, max;
	private int count;
	private double mean;
	private double std;

	@Override
	public void addData(double data) {
		list.add(data);
		stats();
	}

	@Override
	public int getCount() {	
		return list.size();
	}

	@Override
	public double getMin() {
		return Collections.min(list);
	}

	@Override
	public double getMax() {
		return Collections.max(list);
	}

	@Override
	public double getMean() {
		double sum = 0;
        for (double i : list) {
            sum += i;
        }
       return sum / list.size();
	}

	@Override
	public double getSTD() {
		double standardDeviation = 0.0;

        for(double i: list) {
            standardDeviation += Math.pow(i - mean, 2);
        }
        return Math.sqrt(standardDeviation/count);
	}

	@Override
	public void stats() {
		count = getCount();
		min = getMin();
		max = getMax();
		mean = getMean();
		std = getSTD();
	}

}
