package com.ec.lab;

import java.util.logging.Logger;

/** 
* @file StatisticsMain.java 
* @brief This is file the StatisticsMain class containing the main function.
* @author HBF 
*/

/**
 * @class StatisticsMain
 * 
 * @brief StatisticsMain class for the main function.
 * 
 *        <ul>
 *        <li>main function creates Statistics instance</li>
 *        <li>call method addData with parameter</li>
 *        <li>print the countmax,min,mean,std of data in arrayList</li>
 *        </ul>
 */
public class StatisticsMain {
	/**
	 * @brief main function
	 * 
	 *        Calculate the count, min, max, mean, std of data in arrayList
	 */
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	public static void main(String[] args) {
		StatisticsI statistics = new Statistics();
		for (int i = 1; i <= 100; i++) {
			statistics.addData(i);
		}
		int count = statistics.getCount();
		System.out.println("This is count" + count);
		LOGGER.info("This is count" + count);

		double min = statistics.getMin();
		System.out.println("This is min" + min);
		LOGGER.info("This is min" + min);

		double max = statistics.getMax();
		System.out.println("This is max" + max);
		LOGGER.info("This is max" + max);

		double mean = statistics.getMean();
		System.out.println("This is mean" + mean);
		LOGGER.info("This is mean" + mean);

		double std = statistics.getSTD();
		System.out.println("This is STD" + std);
		LOGGER.info("This is STD" + std);
	}
}
