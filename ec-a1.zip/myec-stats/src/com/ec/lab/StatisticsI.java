package com.ec.lab;


public interface StatisticsI {

	void addData(double data); // adding a data element 
	int getCount(); // returning the number of elements
	double getMin(); //returning the minimum element
	double getMax(); // returning maximum element
	double getMean(); //returning the mean
	double getSTD(); //returning standard deviation
	void stats(); //computing the descriptive statistics
	
}
