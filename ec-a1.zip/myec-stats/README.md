# Build Java Project by Apache ANT
Author: Kavita Soni  
Date: January 25, 2020 (update)  

## This project is to demonstrate ant
[Apache Ant](https://ant.apache.org/) is a Java library and command-line tool to build, test and run Java applications. Ant can also be used effectively to build non Java applications, e.g., C or C++ applications similar to C build tool make. Ant can be used to do procedures of targets and tasks. Ant procedure is commonly described in the build.xml file.

This project provides the basic functionality of computing stats for a simple ArrayList which hold values of the type double.
Using the functionality one can get the total count of the data in the array list, can also retrieve min, max, mean and standard deviation of the the data in the Array List.
