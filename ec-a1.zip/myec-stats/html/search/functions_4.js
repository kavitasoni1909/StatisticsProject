var searchData=
[
  ['stats',['stats',['../classcom_1_1ec_1_1lab_1_1_statistics.html#a5b909ddcd186b79e5f4918d8fdbb8c5b',1,'com.ec.lab.Statistics.stats()'],['../interfacecom_1_1ec_1_1lab_1_1_statistics_i.html#a0553f9967bed3e0bf13e0e0f5240b635',1,'com.ec.lab.StatisticsI.stats()']]]
];
