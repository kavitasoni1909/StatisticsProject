var searchData=
[
  ['getcount',['getCount',['../classcom_1_1ec_1_1lab_1_1_statistics.html#ab00e0a9d4fe7acadfb6b4c3a1fe00d75',1,'com.ec.lab.Statistics.getCount()'],['../interfacecom_1_1ec_1_1lab_1_1_statistics_i.html#a8f8f96ae6cb9d35b5eb54aa116c1bd1a',1,'com.ec.lab.StatisticsI.getCount()']]],
  ['getmax',['getMax',['../classcom_1_1ec_1_1lab_1_1_statistics.html#ab674b19eab291383ea29be7a5900ae2f',1,'com.ec.lab.Statistics.getMax()'],['../interfacecom_1_1ec_1_1lab_1_1_statistics_i.html#a119420ae54a41c781dfa1223c035b65e',1,'com.ec.lab.StatisticsI.getMax()']]],
  ['getmean',['getMean',['../classcom_1_1ec_1_1lab_1_1_statistics.html#a82b0c360d296bdc96d033dfb62142045',1,'com.ec.lab.Statistics.getMean()'],['../interfacecom_1_1ec_1_1lab_1_1_statistics_i.html#a1ef11cc9712c8c6f98c599770e163216',1,'com.ec.lab.StatisticsI.getMean()']]],
  ['getmin',['getMin',['../classcom_1_1ec_1_1lab_1_1_statistics.html#abff52644b612f3c2b2f5f41cb3df9f75',1,'com.ec.lab.Statistics.getMin()'],['../interfacecom_1_1ec_1_1lab_1_1_statistics_i.html#aceb73ef5bde1d39e9b768bb6db6d8a24',1,'com.ec.lab.StatisticsI.getMin()']]],
  ['getstd',['getSTD',['../classcom_1_1ec_1_1lab_1_1_statistics.html#a692b41f2e12dce2ef61f39f4ae176418',1,'com.ec.lab.Statistics.getSTD()'],['../interfacecom_1_1ec_1_1lab_1_1_statistics_i.html#ab60dd55b0d789089b9ae3b1240cf5485',1,'com.ec.lab.StatisticsI.getSTD()']]]
];
