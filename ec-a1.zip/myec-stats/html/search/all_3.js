var searchData=
[
  ['initstatistics',['initStatistics',['../classcom_1_1ec_1_1lab_1_1junit_1_1_statistics_test.html#aea6a3da2eaa8079a8a81febfdc84816e',1,'com::ec::lab::junit::StatisticsTest']]]
];
