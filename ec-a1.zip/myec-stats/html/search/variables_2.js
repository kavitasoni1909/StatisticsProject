var searchData=
[
  ['mean',['mean',['../classcom_1_1ec_1_1lab_1_1_statistics.html#ab5fe81e9f6a589fa8cc67034937607cf',1,'com::ec::lab::Statistics']]],
  ['min',['min',['../classcom_1_1ec_1_1lab_1_1_statistics.html#af6236f781bf3b42c00526f2b9d2b84ce',1,'com::ec::lab::Statistics']]]
];
