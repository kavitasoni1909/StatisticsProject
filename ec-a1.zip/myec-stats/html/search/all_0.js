var searchData=
[
  ['adddata',['addData',['../classcom_1_1ec_1_1lab_1_1_statistics.html#a2bb83c6694316aa6494b28ed1fdf20b9',1,'com.ec.lab.Statistics.addData()'],['../interfacecom_1_1ec_1_1lab_1_1_statistics_i.html#a53df99fdb496f3351b760e984c6c0c85',1,'com.ec.lab.StatisticsI.addData()']]]
];
