var searchData=
[
  ['statistics',['statistics',['../classcom_1_1ec_1_1lab_1_1junit_1_1_statistics_test.html#a5f9143d743082bc012ab328bc5202e58',1,'com::ec::lab::junit::StatisticsTest']]],
  ['std',['std',['../classcom_1_1ec_1_1lab_1_1_statistics.html#a49bc3d7edb4993ce600817bcd0f73724',1,'com::ec::lab::Statistics']]]
];
