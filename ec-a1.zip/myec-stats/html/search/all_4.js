var searchData=
[
  ['list',['list',['../classcom_1_1ec_1_1lab_1_1_statistics.html#ab4752e077e522cfbcffa6823f826c588',1,'com::ec::lab::Statistics']]],
  ['logger',['LOGGER',['../classcom_1_1ec_1_1lab_1_1_statistics_main.html#ae6c8b2f0a1276a87c3e29dc4989b7249',1,'com::ec::lab::StatisticsMain']]]
];
