package com.ec.lab.junit;

import static org.junit.Assert.assertEquals;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.ec.lab.Statistics;
import com.ec.lab.StatisticsI;

public class StatisticsTest {

private static StatisticsI statistics = new Statistics();
	
	@BeforeClass
	public static void initStatistics() {
		for(int i = 1; i <=5; i++) {
			statistics.addData(i*2);
		}
	}
	
	@Test
	public void testCount() {
		int size = statistics.getCount();
		assertEquals(5, size);
		
	}
	
	@Test
	public void testMax() {
		double max = statistics.getMax();
		Assert.assertEquals(10.0, max, 0);
	}
	
	@Test
	public void testMin() {
		double min = statistics.getMin();
		Assert.assertEquals(2.0, min, 0);
	}
	
	@Test
	public void testMean() {
		double max = statistics.getMean();
		Assert.assertEquals(6.0, max, 0);
	}
	
	@Test
	public void testSTD() {
		double max = statistics.getSTD();
		Assert.assertEquals(2.8284271247461903, max, 0);
	}
	
}
