package com.ec.lab;

import java.io.IOException;
import java.io.PrintWriter;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/StatsEJBStatelessServlet")
public class StatsEJBStatelessServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@EJB
	private StatsEJBStateless stateless;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		try {
			out.println("EJB and Web component");
			String message = request.getParameter("message");
			out.println("query message: " + message + ",");
			switch (message) {
			case "count":
				out.println("Count: "+stateless.getCount());
				break;
			case "min":
				out.println("Min: "+stateless.getMin());
				break;
			case "max":
				out.println("Max: "+stateless.getMax());
				break;
			case "mean":
				out.println("Mean: "+stateless.getMean());
				break;
			case "std":
				out.println("Std: "+stateless.getSTD());
				break;
			case "summary":
				out.println("Summary: "+stateless.loadModel().toString());
				break;
			default:
				break;
			}
			out.println("<br>");

		} catch (Exception ex) {
			throw new ServletException(ex);
		} finally {
			out.close();
		}
	}
}
